﻿Option Explicit On
Option Strict On
Imports System.Text

Public Class frmMain
    Dim mConnected As Boolean
    Dim mConnectionID As Integer
    Dim mUpdatingUI As Boolean 'used in the value changed event for UI controls so that the value isn't sent to the controller when initializing the UI
    Dim mCh1DistanceUnits As String 'after initializing the UI, this is used again if saving a recording CSV file for the column header

    Private Sub frmMain_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        If mConnected = True Then
            disconnect()
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listDevices()
    End Sub

    Private Sub btnListDevices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnListDevices.Click
        listDevices()
    End Sub

    Private Sub listDevices()
        Try
            lstDeviceList.Items.Clear()
            Dim success As Integer
            Dim numDevices As Integer
            Dim serialNum As New StringBuilder(16) 'USB Serial Number is a 16 character char array
            Dim description As New StringBuilder(64) 'USB Description is a 64 character char array

            'Determine the number of nPoint devices connected to the PC
            success = LC400API.buildAvailUSB_devList(numDevices)

            'Loop through the devices to retreive the serialnumber and description to populate the listbox control
            If success = 0 And numDevices > 0 Then
                For i As Integer = 0 To numDevices - 1
                    success = LC400API.getAvailUSB_devInfo(i, serialNum, description)
                    If success <> 0 Then
                        Throw New Exception("Error getting device serial number and description")
                    End If
                    lstDeviceList.Items.Add(serialNum.ToString & " - " & description.ToString)
                Next
            End If
            If lstDeviceList.Items.Count = 1 Then
                lstDeviceList.SelectedIndex = 0
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        connect()
    End Sub

    Private Sub connect()
        Try
            Dim success As Integer
            Dim numChannels As Integer
            Dim ch1Range As Single
            Dim ch1DistanceUnits As Integer
            Dim ch1PositionCmd As Single

            If lstDeviceList.SelectedIndex = -1 Then
                MsgBox("Please select an FTDI device from the list")
            Else
                success = LC400API.connectUSB(lstDeviceList.SelectedIndex, mConnectionID)
                If success = 0 Then
                    mConnected = True
                    'determine the number of channels in the controller
                    success = LC400API.getNumChannels(mConnectionID, numChannels)
                    If success <> 0 Or numChannels < 1 Then
                        Throw New Exception("Error getting the number of controller channels.")
                    End If
                    'get Ch1 range and distance units
                    success = LC400API.getRange(mConnectionID, 1, ch1Range, ch1DistanceUnits)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch1 travel range.")
                    End If
                    'set the numeric entry UI control minimum and maximum values
                    numDigitalPosition.Maximum = Convert.ToDecimal(ch1Range / 2)
                    numDigitalPosition.Minimum = Convert.ToDecimal(ch1Range / 2 * -1)
                    numAmplitude.Maximum = Convert.ToDecimal(ch1Range / 2) 'waveform sinewave amplitude is half the peak to peak value
                    numMoveSize.Maximum = Convert.ToDecimal(ch1Range)
                    numMoveSize.Minimum = Convert.ToDecimal(ch1Range * -1)
                    'initialize the UI distance unit labels
                    Select Case ch1DistanceUnits
                        Case 0
                            mCh1DistanceUnits = "microns"
                            lblTrajMoveVel.Text = "mm/sec"
                            lblTrajMoveAccel.Text = "mm/sec²"
                            lblTrajMoveJerk.Text = "mm/sec³"
                        Case 1
                            mCh1DistanceUnits = "millimeters"
                            lblTrajMoveVel.Text = "m/sec"
                            lblTrajMoveAccel.Text = "m/sec²"
                            lblTrajMoveJerk.Text = "m/sec³"
                        Case 2
                            mCh1DistanceUnits = "µradians"
                            lblTrajMoveVel.Text = "mrad/sec"
                            lblTrajMoveAccel.Text = "mrad/sec²"
                            lblTrajMoveJerk.Text = "mrad/sec³"
                        Case 5
                            mCh1DistanceUnits = "milliradians"
                            lblTrajMoveVel.Text = "rad/sec"
                            lblTrajMoveAccel.Text = "rad/sec²"
                            lblTrajMoveJerk.Text = "rad/sec³"
                        Case Else
                            mCh1DistanceUnits = "microns"
                            lblTrajMoveVel.Text = "mm/sec"
                            lblTrajMoveAccel.Text = "mm/sec²"
                            lblTrajMoveJerk.Text = "mm/sec³"
                    End Select
                    lblCh1RangeUnits.Text = mCh1DistanceUnits
                    lblCh1RangeUnits2.Text = mCh1DistanceUnits
                    lblCh1RangeUnits3.Text = mCh1DistanceUnits
                    lblCh1RangeUnits4.Text = mCh1DistanceUnits
                    'query current Ch1 Digital Position Command and initialize the UI
                    success = LC400API.getDigPosition(mConnectionID, 1, ch1PositionCmd)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch1 digital position command.")
                    End If
                    mUpdatingUI = True
                    If ch1PositionCmd > numDigitalPosition.Maximum Then
                        numDigitalPosition.Value = numDigitalPosition.Maximum
                        MsgBox("Digital Position Command value is greater than the calibrated stage travel maximum.", MsgBoxStyle.Exclamation, "Error")
                    ElseIf ch1PositionCmd < numDigitalPosition.Minimum Then
                        numDigitalPosition.Value = numDigitalPosition.Minimum
                        MsgBox("Digital Position Command value is less than the calibrated stage travel minimum.", MsgBoxStyle.Exclamation, "Error")
                    Else
                        numDigitalPosition.Value = Convert.ToDecimal(ch1PositionCmd)
                    End If
                    mUpdatingUI = False
                    btnConnect.Visible = False
                    btnDisconnect.Visible = True
                    grpDigitalPosition.Visible = True
                    grpTrajectory.Visible = True
                    grpSensor.Visible = True
                    grpRecordParam.Visible = True
                    grpWaveform.Visible = True
                Else
                    mConnected = False
                    Throw New Exception("Error connecting to the selected device")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            mUpdatingUI = False
        End Try
    End Sub

    Private Sub lstDeviceList_DoubleClick(sender As Object, e As System.EventArgs) Handles lstDeviceList.DoubleClick
        connect()
    End Sub

    Private Sub btnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisconnect.Click
        disconnect()
    End Sub

    Private Sub disconnect()
        Try
            mConnected = False
            btnConnect.Visible = True
            btnDisconnect.Visible = False
            grpDigitalPosition.Visible = False
            grpTrajectory.Visible = False
            grpSensor.Visible = False
            grpRecordParam.Visible = False
            grpWaveform.Visible = False
            txtSensorValue.Text = ""
            Dim success As Integer = LC400API.disconnect(mConnectionID)
            If success <> 0 Then
                Throw New System.Exception("An error occurred when closing the USB connection.")
            End If
            listDevices() 'update list of USB devices available to connect to
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub btnQuerySensor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuerySensor.Click
        Try
            'query the sensor reading, populate the text box with a scaled value
            Dim ch1SensorReading As Single
            Dim success As Integer = LC400API.getSensorMonitor(mConnectionID, 1, ch1SensorReading)
            If success = 0 Then
                txtSensorValue.Text = ch1SensorReading.ToString("0.000")
            Else
                Throw New System.Exception("An error occurred when reading the sensor monitor value.")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub numDigitalPosition_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numDigitalPosition.ValueChanged
        If Not mUpdatingUI Then
            Try
                Dim success As Integer = LC400API.setDigPosition(mConnectionID, 1, numDigitalPosition.Value)
                If success <> 0 Then
                    Throw New System.Exception("An error occurred when sending the digital position command.")
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            End Try
        End If
    End Sub

    Private Sub btnStartTraj_Click(sender As System.Object, e As System.EventArgs) Handles btnStartTraj.Click
        'Start trajectory
        Try
            btnStartTraj.Enabled = False
            'get the current position
            Dim currentPos As Single
            Dim success As Integer = LC400API.getDigPosition(mConnectionID, 1, currentPos)
            If success <> 0 Then
                Throw New System.Exception("An error occurred reading the current digital position command.")
            End If
            Dim newPosition As Single = currentPos + numMoveSize.Value

            'If necessary, start the recording function
            If chkRecordTraj.Checked = True Then
                startRecording()
            End If

            'Enable the trajectory function for Ch1
            success = LC400API.setTrajEnable(mConnectionID, 1, 1)
            If success <> 0 Then
                Throw New System.Exception("An error occurred setting the trajectory enable state.")
            End If
            'Disable the trajectory function for Ch2 and Ch3 since this example is only for Ch1
            success = LC400API.setTrajEnable(mConnectionID, 2, 0)
            If success <> 0 Then
                Throw New System.Exception("An error occurred setting the trajectory enable state.")
            End If
            success = LC400API.setTrajEnable(mConnectionID, 3, 0)
            If success <> 0 Then
                Throw New System.Exception("An error occurred setting the trajectory enable state.")
            End If

            'Send the trajectory command based on the user interface parameters
            success = LC400API.singleTrajMove(mConnectionID, newPosition, 0, 0, numVelocity.Value, numAcceleration.Value, numJerk.Value, 0)
            If success <> 0 Then
                Throw New System.Exception("An error occurred sending the trajectory parameters.")
            End If

            'start query timer to poll for trajectory completion
            tmrCheckTrajectoryState.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub btnStopTraj_Click(sender As System.Object, e As System.EventArgs) Handles btnStopTraj.Click
        'Stop trajectory
        Try
            'disable trajectory state query timer, send stop command, update the digital position user interface control with the position set by the trajectory function
            tmrCheckTrajectoryState.Enabled = False
            Dim success As Integer = LC400API.stopTraj(mConnectionID)
            If success <> 0 Then
                Throw New System.Exception("An error occurred sending the trajectory stop command.")
            End If
            Dim currentPos As Single
            success = LC400API.getDigPosition(mConnectionID, 1, currentPos)
            If success <> 0 Then
                Throw New System.Exception("An error occurred reading the current digital position command.")
            End If
            mUpdatingUI = True
            numDigitalPosition.Value = Convert.ToDecimal(currentPos)
            mUpdatingUI = False
            btnStartTraj.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            mUpdatingUI = False
        End Try
    End Sub

    Private Sub tmrCheckTrajectoryState_Tick(sender As System.Object, e As System.EventArgs) Handles tmrCheckTrajectoryState.Tick
        Try
            Dim tgStatus As Integer
            Dim success As Integer = LC400API.getTrajStatus(mConnectionID, tgStatus)
            If tgStatus = 0 Then
                'trajectory has completed, disable query timer and update the digital position user interface control with the position set by the trajectory function
                tmrCheckTrajectoryState.Enabled = False
                btnStartTraj.Enabled = True
                Dim currentPos As Single
                success = LC400API.getDigPosition(mConnectionID, 1, currentPos)
                If success <> 0 Then
                    Throw New System.Exception("An error occurred reading the current digital position command.")
                End If
                mUpdatingUI = True
                If currentPos > numDigitalPosition.Maximum Then
                    numDigitalPosition.Value = numDigitalPosition.Maximum
                    MsgBox("Digital Position Command value is greater than the calibrated stage travel maximum.", MsgBoxStyle.Exclamation, "Error")
                ElseIf currentPos < numDigitalPosition.Minimum Then
                    numDigitalPosition.Value = numDigitalPosition.Minimum
                    MsgBox("Digital Position Command value is less than the calibrated stage travel minimum.", MsgBoxStyle.Exclamation, "Error")
                Else
                    numDigitalPosition.Value = Convert.ToDecimal(currentPos)
                End If
                mUpdatingUI = False
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            tmrCheckTrajectoryState.Enabled = False
            mUpdatingUI = False
        End Try
    End Sub

    Private Sub btnStartRecording_Click(sender As System.Object, e As System.EventArgs) Handles btnStartRecording.Click
        startRecording()
    End Sub

    Private Sub startRecording()
        Try
            btnStartRecording.Enabled = False
            Dim success As Integer = LC400API.setRecPointer(mConnectionID, 0, 1, 2) 'set the recording pointer for buffer0 to ch1 position command
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            success = LC400API.setRecPointer(mConnectionID, 1, 1, 1) 'set the recording pointer for buffer1 to ch1 sensor monitor
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            'set the other buffers for no recording
            For i As Integer = 2 To 7
                success = LC400API.setRecPointer(mConnectionID, i, 0, 0) 'set no recording for buffer2 through buffer7
                If success <> 0 Then
                    Throw New Exception("An error occurred setting the recording parameters")
                End If
            Next
           
            'start the recording
            success = LC400API.startRec(mConnectionID, Convert.ToInt32(numNumberSamples.Value), Convert.ToInt32(numCyclesPerSample.Value))
            If success <> 0 Then
                Throw New Exception("An error occurred starting the recording function")
            End If
            tmrCheckForRecComplete.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub tmrCheckForRecComplete_Tick(sender As System.Object, e As System.EventArgs) Handles tmrCheckForRecComplete.Tick
        Try
            Dim recStatus As Integer
            Dim index As Integer
            Dim success As Integer = LC400API.getRecStatus(mConnectionID, recStatus, index)
            If success <> 0 Then
                Throw New Exception("An error occurred when reading the recording status")
            End If
            If recStatus = 0 Then 'recording is completed
                tmrCheckForRecComplete.Enabled = False
                btnStartRecording.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            tmrCheckForRecComplete.Enabled = False
        End Try
    End Sub

    Private Sub btnSaveToFile_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveToFile.Click
        Dim fileStreamOpen As Boolean = False
        Dim numSamples As Integer = Convert.ToInt32(Math.Round(numNumberSamples.Value))
        Dim time As Single = 0
        Dim timeIncrement As Single
        'determine time between samples based on the number of control loop cycles per sample value
        timeIncrement = Convert.ToSingle(Math.Round(numCyclesPerSample.Value, 0) * 0.000024)

        'read buffers for Ch1 Position Cmd and Ch1 Sensor Monitor values
        Dim ch1PosCmdBuffer(numSamples - 1) As Single
        Dim ch1SensorMonBuffer(numSamples - 1) As Single
        Dim success As Integer = LC400API.getScaledRecBuffer(mConnectionID, 0, ch1PosCmdBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        success = LC400API.getScaledRecBuffer(mConnectionID, 1, ch1SensorMonBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        'open a save file dialog for the user to choose a file path
        Try
            Dim dialogReturn As Integer
            dlgSaveRecording.Filter = "CSV Files|*.csv|All Files|*.*"
            dialogReturn = dlgSaveRecording.ShowDialog
            If dialogReturn = DialogResult.Cancel Then
                Exit Sub
            Else
                Dim fileStream As System.IO.StreamWriter = New System.IO.StreamWriter(dlgSaveRecording.FileName)
                fileStreamOpen = True
                Try
                    'write the column header row
                    fileStream.Write("Time (seconds),Ch1 Position Cmd (" & mCh1DistanceUnits & _
                                     "),Ch1 Sensor Mon (" & mCh1DistanceUnits & ")" & vbCrLf)
                    'write the data rows
                    For i = 0 To numSamples - 1
                        fileStream.Write(time.ToString & "," & ch1PosCmdBuffer(i).ToString & "," & ch1SensorMonBuffer(i).ToString & vbCrLf)
                        time += timeIncrement
                    Next
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
                Finally
                    If fileStreamOpen = True Then
                        fileStream.Close()
                    End If
                End Try
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub numNumberSamples_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numNumberSamples.ValueChanged
        lblRecTime.Text = (Math.Round(numNumberSamples.Value, 0) * Math.Round(numCyclesPerSample.Value, 0) * 0.000024).ToString("0.000000") & " sec"
    End Sub

    Private Sub numCyclesPerSample_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numCyclesPerSample.ValueChanged
        lblRecTime.Text = (Math.Round(numNumberSamples.Value, 0) * Math.Round(numCyclesPerSample.Value, 0) * 0.000024).ToString("0.000000") & " sec"
    End Sub

    Private Sub btnStartWaveform_Click(sender As System.Object, e As System.EventArgs) Handles btnStartWaveform.Click
        Try
            Dim success As Integer
            'determine the waveform period
            Dim period As Double = 1 / numFrequency.Value
            'determine the number of points per period if the output rate is 24 µs
            Dim numPoints As Double = period / 0.000024
            'determine if the output rate needs to be reduced for the number of points to be < 83,333
            Dim loopCyclesPerSample As Integer = Convert.ToInt32(Math.Floor(numPoints / 83333))
            'if the output rate is reduced, scale numpoints, round to an integer
            Dim numPointsInt As Integer = Convert.ToInt32(Math.Round(numPoints / (loopCyclesPerSample + 1)))
            'create the array that will hold the sinewave
            Dim wave(numPointsInt) As Single
            'fill the "wave" array with the sine points
            Dim currentPhase As Double = 0 'Math.PI * -0.5 would start the sinewave at the minimum value
            Dim phaseIncrement As Double = (2 * Math.PI) / numPointsInt
            For i = 0 To numPointsInt - 1
                wave(i) = Convert.ToSingle(numAmplitude.Value * Math.Sin(currentPhase))
                currentPhase += phaseIncrement
            Next
            'load the controller waveform buffer
            success = LC400API.loadWaveform(mConnectionID, 1, wave, numPointsInt, loopCyclesPerSample, Convert.ToInt32(Math.Round(numIterations.Value)))
            If success <> 0 Then
                Throw New Exception("Error loading the waveform buffer")
            End If
            'start the Ch1 waveform, value of 1 runs indefinitely, value of 2 is used for finite iterations
            If chkInfinite.Checked = True Then
                success = LC400API.simWaveformStart(mConnectionID, 1, 0, 0)
                If success <> 0 Then
                    Throw New Exception("Error starting the waveform")
                End If
            Else
                success = LC400API.simWaveformStart(mConnectionID, 2, 0, 0)
                If success <> 0 Then
                    Throw New Exception("Error starting the waveform")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub btnStopWaveform_Click(sender As System.Object, e As System.EventArgs) Handles btnStopWaveform.Click
        Try
            Dim success As Integer = LC400API.stopCh1Ch2Ch3Waveforms(mConnectionID)
            If success <> 0 Then
                Throw New Exception("Error stopping the waveform")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub chkInfinite_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkInfinite.CheckedChanged
        If chkInfinite.Checked = True Then
            numIterations.Enabled = False
        Else
            numIterations.Enabled = True
        End If
    End Sub

End Class
