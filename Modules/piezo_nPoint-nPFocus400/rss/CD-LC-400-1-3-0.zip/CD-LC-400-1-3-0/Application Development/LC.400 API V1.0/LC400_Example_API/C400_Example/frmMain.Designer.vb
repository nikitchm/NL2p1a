﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnListDevices = New System.Windows.Forms.Button()
        Me.lstDeviceList = New System.Windows.Forms.ListBox()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.btnDisconnect = New System.Windows.Forms.Button()
        Me.btnQuerySensor = New System.Windows.Forms.Button()
        Me.txtSensorValue = New System.Windows.Forms.TextBox()
        Me.lblCh1RangeUnits2 = New System.Windows.Forms.Label()
        Me.numDigitalPosition = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.numMoveSize = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.numVelocity = New System.Windows.Forms.NumericUpDown()
        Me.lblCh1RangeUnits4 = New System.Windows.Forms.Label()
        Me.lblCh1RangeUnits = New System.Windows.Forms.Label()
        Me.lblTrajMoveVel = New System.Windows.Forms.Label()
        Me.grpTrajectory = New System.Windows.Forms.GroupBox()
        Me.btnStopTraj = New System.Windows.Forms.Button()
        Me.lblTrajMoveJerk = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.numJerk = New System.Windows.Forms.NumericUpDown()
        Me.lblTrajMoveAccel = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.numAcceleration = New System.Windows.Forms.NumericUpDown()
        Me.btnStartTraj = New System.Windows.Forms.Button()
        Me.grpSensor = New System.Windows.Forms.GroupBox()
        Me.grpDigitalPosition = New System.Windows.Forms.GroupBox()
        Me.tmrCheckTrajectoryState = New System.Windows.Forms.Timer(Me.components)
        Me.grpRecordParam = New System.Windows.Forms.GroupBox()
        Me.chkRecordTraj = New System.Windows.Forms.CheckBox()
        Me.lblRecTime = New System.Windows.Forms.Label()
        Me.label70 = New System.Windows.Forms.Label()
        Me.numCyclesPerSample = New System.Windows.Forms.NumericUpDown()
        Me.btnSaveToFile = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.numNumberSamples = New System.Windows.Forms.NumericUpDown()
        Me.btnStartRecording = New System.Windows.Forms.Button()
        Me.tmrCheckForRecComplete = New System.Windows.Forms.Timer(Me.components)
        Me.dlgSaveRecording = New System.Windows.Forms.SaveFileDialog()
        Me.grpWaveform = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblCh1RangeUnits3 = New System.Windows.Forms.Label()
        Me.chkInfinite = New System.Windows.Forms.CheckBox()
        Me.btnStopWaveform = New System.Windows.Forms.Button()
        Me.btnStartWaveform = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.numIterations = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.numFrequency = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.numAmplitude = New System.Windows.Forms.NumericUpDown()
        CType(Me.numDigitalPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numMoveSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numVelocity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTrajectory.SuspendLayout()
        CType(Me.numJerk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numAcceleration, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpSensor.SuspendLayout()
        Me.grpDigitalPosition.SuspendLayout()
        Me.grpRecordParam.SuspendLayout()
        CType(Me.numCyclesPerSample, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numNumberSamples, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpWaveform.SuspendLayout()
        CType(Me.numIterations, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numFrequency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numAmplitude, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnListDevices
        '
        Me.btnListDevices.Location = New System.Drawing.Point(12, 152)
        Me.btnListDevices.Name = "btnListDevices"
        Me.btnListDevices.Size = New System.Drawing.Size(165, 37)
        Me.btnListDevices.TabIndex = 2
        Me.btnListDevices.Text = "List nPoint Devices"
        Me.btnListDevices.UseVisualStyleBackColor = True
        '
        'lstDeviceList
        '
        Me.lstDeviceList.FormattingEnabled = True
        Me.lstDeviceList.Location = New System.Drawing.Point(12, 12)
        Me.lstDeviceList.Name = "lstDeviceList"
        Me.lstDeviceList.Size = New System.Drawing.Size(165, 134)
        Me.lstDeviceList.TabIndex = 1
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(12, 195)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(165, 37)
        Me.btnConnect.TabIndex = 3
        Me.btnConnect.Text = "Connect to Selected Device"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Location = New System.Drawing.Point(12, 197)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(165, 37)
        Me.btnDisconnect.TabIndex = 8
        Me.btnDisconnect.Text = "Disconnect"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        Me.btnDisconnect.Visible = False
        '
        'btnQuerySensor
        '
        Me.btnQuerySensor.Location = New System.Drawing.Point(28, 26)
        Me.btnQuerySensor.Name = "btnQuerySensor"
        Me.btnQuerySensor.Size = New System.Drawing.Size(119, 30)
        Me.btnQuerySensor.TabIndex = 6
        Me.btnQuerySensor.Text = "Query Sensor Value"
        Me.btnQuerySensor.UseVisualStyleBackColor = True
        '
        'txtSensorValue
        '
        Me.txtSensorValue.Location = New System.Drawing.Point(157, 31)
        Me.txtSensorValue.Name = "txtSensorValue"
        Me.txtSensorValue.ReadOnly = True
        Me.txtSensorValue.Size = New System.Drawing.Size(84, 20)
        Me.txtSensorValue.TabIndex = 7
        Me.txtSensorValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblCh1RangeUnits2
        '
        Me.lblCh1RangeUnits2.AutoSize = True
        Me.lblCh1RangeUnits2.Location = New System.Drawing.Point(245, 35)
        Me.lblCh1RangeUnits2.Name = "lblCh1RangeUnits2"
        Me.lblCh1RangeUnits2.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits2.TabIndex = 13
        Me.lblCh1RangeUnits2.Text = "microns"
        '
        'numDigitalPosition
        '
        Me.numDigitalPosition.DecimalPlaces = 3
        Me.numDigitalPosition.Location = New System.Drawing.Point(157, 24)
        Me.numDigitalPosition.Name = "numDigitalPosition"
        Me.numDigitalPosition.Size = New System.Drawing.Size(84, 20)
        Me.numDigitalPosition.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Digital Position Command"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(52, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Relative Move Size"
        '
        'numMoveSize
        '
        Me.numMoveSize.DecimalPlaces = 3
        Me.numMoveSize.Location = New System.Drawing.Point(157, 19)
        Me.numMoveSize.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numMoveSize.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.numMoveSize.Name = "numMoveSize"
        Me.numMoveSize.Size = New System.Drawing.Size(84, 20)
        Me.numMoveSize.TabIndex = 16
        Me.numMoveSize.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(77, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Move Velocity"
        '
        'numVelocity
        '
        Me.numVelocity.DecimalPlaces = 3
        Me.numVelocity.Location = New System.Drawing.Point(157, 45)
        Me.numVelocity.Name = "numVelocity"
        Me.numVelocity.Size = New System.Drawing.Size(84, 20)
        Me.numVelocity.TabIndex = 20
        Me.numVelocity.Value = New Decimal(New Integer() {1, 0, 0, 131072})
        '
        'lblCh1RangeUnits4
        '
        Me.lblCh1RangeUnits4.AutoSize = True
        Me.lblCh1RangeUnits4.Location = New System.Drawing.Point(245, 21)
        Me.lblCh1RangeUnits4.Name = "lblCh1RangeUnits4"
        Me.lblCh1RangeUnits4.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits4.TabIndex = 25
        Me.lblCh1RangeUnits4.Text = "microns"
        '
        'lblCh1RangeUnits
        '
        Me.lblCh1RangeUnits.AutoSize = True
        Me.lblCh1RangeUnits.Location = New System.Drawing.Point(245, 26)
        Me.lblCh1RangeUnits.Name = "lblCh1RangeUnits"
        Me.lblCh1RangeUnits.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits.TabIndex = 26
        Me.lblCh1RangeUnits.Text = "microns"
        '
        'lblTrajMoveVel
        '
        Me.lblTrajMoveVel.AutoSize = True
        Me.lblTrajMoveVel.Location = New System.Drawing.Point(245, 47)
        Me.lblTrajMoveVel.Name = "lblTrajMoveVel"
        Me.lblTrajMoveVel.Size = New System.Drawing.Size(45, 13)
        Me.lblTrajMoveVel.TabIndex = 27
        Me.lblTrajMoveVel.Text = "mm/sec"
        '
        'grpTrajectory
        '
        Me.grpTrajectory.Controls.Add(Me.btnStopTraj)
        Me.grpTrajectory.Controls.Add(Me.lblTrajMoveJerk)
        Me.grpTrajectory.Controls.Add(Me.Label13)
        Me.grpTrajectory.Controls.Add(Me.numJerk)
        Me.grpTrajectory.Controls.Add(Me.lblTrajMoveAccel)
        Me.grpTrajectory.Controls.Add(Me.Label11)
        Me.grpTrajectory.Controls.Add(Me.numAcceleration)
        Me.grpTrajectory.Controls.Add(Me.btnStartTraj)
        Me.grpTrajectory.Controls.Add(Me.lblTrajMoveVel)
        Me.grpTrajectory.Controls.Add(Me.lblCh1RangeUnits4)
        Me.grpTrajectory.Controls.Add(Me.Label4)
        Me.grpTrajectory.Controls.Add(Me.numVelocity)
        Me.grpTrajectory.Controls.Add(Me.Label2)
        Me.grpTrajectory.Controls.Add(Me.numMoveSize)
        Me.grpTrajectory.Location = New System.Drawing.Point(197, 159)
        Me.grpTrajectory.Name = "grpTrajectory"
        Me.grpTrajectory.Size = New System.Drawing.Size(338, 160)
        Me.grpTrajectory.TabIndex = 28
        Me.grpTrajectory.TabStop = False
        Me.grpTrajectory.Text = "Single Relative Trajectory Move"
        Me.grpTrajectory.Visible = False
        '
        'btnStopTraj
        '
        Me.btnStopTraj.Location = New System.Drawing.Point(172, 124)
        Me.btnStopTraj.Name = "btnStopTraj"
        Me.btnStopTraj.Size = New System.Drawing.Size(102, 28)
        Me.btnStopTraj.TabIndex = 35
        Me.btnStopTraj.Text = "Stop Trajectory"
        Me.btnStopTraj.UseVisualStyleBackColor = True
        '
        'lblTrajMoveJerk
        '
        Me.lblTrajMoveJerk.AutoSize = True
        Me.lblTrajMoveJerk.Location = New System.Drawing.Point(245, 99)
        Me.lblTrajMoveJerk.Name = "lblTrajMoveJerk"
        Me.lblTrajMoveJerk.Size = New System.Drawing.Size(48, 13)
        Me.lblTrajMoveJerk.TabIndex = 34
        Me.lblTrajMoveJerk.Text = "mm/sec³"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(94, 99)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 13)
        Me.Label13.TabIndex = 33
        Me.Label13.Text = "Move Jerk"
        '
        'numJerk
        '
        Me.numJerk.DecimalPlaces = 3
        Me.numJerk.Location = New System.Drawing.Point(157, 97)
        Me.numJerk.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.numJerk.Name = "numJerk"
        Me.numJerk.Size = New System.Drawing.Size(84, 20)
        Me.numJerk.TabIndex = 32
        Me.numJerk.Value = New Decimal(New Integer() {999, 0, 0, 0})
        '
        'lblTrajMoveAccel
        '
        Me.lblTrajMoveAccel.AutoSize = True
        Me.lblTrajMoveAccel.Location = New System.Drawing.Point(245, 73)
        Me.lblTrajMoveAccel.Name = "lblTrajMoveAccel"
        Me.lblTrajMoveAccel.Size = New System.Drawing.Size(48, 13)
        Me.lblTrajMoveAccel.TabIndex = 31
        Me.lblTrajMoveAccel.Text = "mm/sec²"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(55, 73)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 13)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Move Acceleration"
        '
        'numAcceleration
        '
        Me.numAcceleration.DecimalPlaces = 3
        Me.numAcceleration.Location = New System.Drawing.Point(157, 71)
        Me.numAcceleration.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.numAcceleration.Name = "numAcceleration"
        Me.numAcceleration.Size = New System.Drawing.Size(84, 20)
        Me.numAcceleration.TabIndex = 29
        Me.numAcceleration.Value = New Decimal(New Integer() {999, 0, 0, 0})
        '
        'btnStartTraj
        '
        Me.btnStartTraj.Location = New System.Drawing.Point(64, 124)
        Me.btnStartTraj.Name = "btnStartTraj"
        Me.btnStartTraj.Size = New System.Drawing.Size(102, 28)
        Me.btnStartTraj.TabIndex = 28
        Me.btnStartTraj.Text = "Start Trajectory"
        Me.btnStartTraj.UseVisualStyleBackColor = True
        '
        'grpSensor
        '
        Me.grpSensor.Controls.Add(Me.lblCh1RangeUnits2)
        Me.grpSensor.Controls.Add(Me.btnQuerySensor)
        Me.grpSensor.Controls.Add(Me.txtSensorValue)
        Me.grpSensor.Location = New System.Drawing.Point(197, 79)
        Me.grpSensor.Name = "grpSensor"
        Me.grpSensor.Size = New System.Drawing.Size(338, 74)
        Me.grpSensor.TabIndex = 29
        Me.grpSensor.TabStop = False
        Me.grpSensor.Text = "Ch1 Sensor Value"
        Me.grpSensor.Visible = False
        '
        'grpDigitalPosition
        '
        Me.grpDigitalPosition.Controls.Add(Me.lblCh1RangeUnits)
        Me.grpDigitalPosition.Controls.Add(Me.Label1)
        Me.grpDigitalPosition.Controls.Add(Me.numDigitalPosition)
        Me.grpDigitalPosition.Location = New System.Drawing.Point(197, 12)
        Me.grpDigitalPosition.Name = "grpDigitalPosition"
        Me.grpDigitalPosition.Size = New System.Drawing.Size(338, 61)
        Me.grpDigitalPosition.TabIndex = 30
        Me.grpDigitalPosition.TabStop = False
        Me.grpDigitalPosition.Text = "Ch1 Static Digital Position"
        Me.grpDigitalPosition.Visible = False
        '
        'tmrCheckTrajectoryState
        '
        '
        'grpRecordParam
        '
        Me.grpRecordParam.Controls.Add(Me.chkRecordTraj)
        Me.grpRecordParam.Controls.Add(Me.lblRecTime)
        Me.grpRecordParam.Controls.Add(Me.label70)
        Me.grpRecordParam.Controls.Add(Me.numCyclesPerSample)
        Me.grpRecordParam.Controls.Add(Me.btnSaveToFile)
        Me.grpRecordParam.Controls.Add(Me.Label14)
        Me.grpRecordParam.Controls.Add(Me.Label15)
        Me.grpRecordParam.Controls.Add(Me.numNumberSamples)
        Me.grpRecordParam.Controls.Add(Me.btnStartRecording)
        Me.grpRecordParam.Location = New System.Drawing.Point(541, 12)
        Me.grpRecordParam.Name = "grpRecordParam"
        Me.grpRecordParam.Size = New System.Drawing.Size(293, 141)
        Me.grpRecordParam.TabIndex = 31
        Me.grpRecordParam.TabStop = False
        Me.grpRecordParam.Text = "Record Ch1 Position Cmd, Ch1 Sensor Monitor"
        Me.grpRecordParam.Visible = False
        '
        'chkRecordTraj
        '
        Me.chkRecordTraj.AutoSize = True
        Me.chkRecordTraj.Location = New System.Drawing.Point(34, 76)
        Me.chkRecordTraj.Name = "chkRecordTraj"
        Me.chkRecordTraj.Size = New System.Drawing.Size(215, 17)
        Me.chkRecordTraj.TabIndex = 37
        Me.chkRecordTraj.Text = "Start recording when trajectory is started"
        Me.chkRecordTraj.UseVisualStyleBackColor = True
        '
        'lblRecTime
        '
        Me.lblRecTime.AutoSize = True
        Me.lblRecTime.Location = New System.Drawing.Point(169, 48)
        Me.lblRecTime.Name = "lblRecTime"
        Me.lblRecTime.Size = New System.Drawing.Size(72, 13)
        Me.lblRecTime.TabIndex = 36
        Me.lblRecTime.Text = "0.720000 sec"
        '
        'label70
        '
        Me.label70.AutoSize = True
        Me.label70.Location = New System.Drawing.Point(169, 27)
        Me.label70.Name = "label70"
        Me.label70.Size = New System.Drawing.Size(80, 13)
        Me.label70.TabIndex = 35
        Me.label70.Text = "Record Time = "
        '
        'numCyclesPerSample
        '
        Me.numCyclesPerSample.Location = New System.Drawing.Point(93, 48)
        Me.numCyclesPerSample.Maximum = New Decimal(New Integer() {83333, 0, 0, 0})
        Me.numCyclesPerSample.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numCyclesPerSample.Name = "numCyclesPerSample"
        Me.numCyclesPerSample.Size = New System.Drawing.Size(56, 20)
        Me.numCyclesPerSample.TabIndex = 34
        Me.numCyclesPerSample.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numCyclesPerSample.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Location = New System.Drawing.Point(148, 100)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(102, 30)
        Me.btnSaveToFile.TabIndex = 15
        Me.btnSaveToFile.Text = "Save to File"
        Me.btnSaveToFile.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 50)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 13)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "Cycles/Sample:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(15, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(75, 13)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Num Samples:"
        '
        'numNumberSamples
        '
        Me.numNumberSamples.Location = New System.Drawing.Point(93, 20)
        Me.numNumberSamples.Maximum = New Decimal(New Integer() {83333, 0, 0, 0})
        Me.numNumberSamples.Name = "numNumberSamples"
        Me.numNumberSamples.Size = New System.Drawing.Size(56, 20)
        Me.numNumberSamples.TabIndex = 9
        Me.numNumberSamples.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numNumberSamples.Value = New Decimal(New Integer() {30000, 0, 0, 0})
        '
        'btnStartRecording
        '
        Me.btnStartRecording.Location = New System.Drawing.Point(34, 100)
        Me.btnStartRecording.Name = "btnStartRecording"
        Me.btnStartRecording.Size = New System.Drawing.Size(102, 30)
        Me.btnStartRecording.TabIndex = 14
        Me.btnStartRecording.Text = "Start Recording"
        Me.btnStartRecording.UseVisualStyleBackColor = True
        '
        'tmrCheckForRecComplete
        '
        '
        'grpWaveform
        '
        Me.grpWaveform.Controls.Add(Me.Label3)
        Me.grpWaveform.Controls.Add(Me.lblCh1RangeUnits3)
        Me.grpWaveform.Controls.Add(Me.chkInfinite)
        Me.grpWaveform.Controls.Add(Me.btnStopWaveform)
        Me.grpWaveform.Controls.Add(Me.btnStartWaveform)
        Me.grpWaveform.Controls.Add(Me.Label5)
        Me.grpWaveform.Controls.Add(Me.numIterations)
        Me.grpWaveform.Controls.Add(Me.Label6)
        Me.grpWaveform.Controls.Add(Me.numFrequency)
        Me.grpWaveform.Controls.Add(Me.Label8)
        Me.grpWaveform.Controls.Add(Me.numAmplitude)
        Me.grpWaveform.Location = New System.Drawing.Point(541, 159)
        Me.grpWaveform.Name = "grpWaveform"
        Me.grpWaveform.Size = New System.Drawing.Size(293, 139)
        Me.grpWaveform.TabIndex = 32
        Me.grpWaveform.TabStop = False
        Me.grpWaveform.Text = "Arbitrary Periodic Waveform - Ch1 Sine Wave"
        Me.grpWaveform.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(153, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Hz"
        '
        'lblCh1RangeUnits3
        '
        Me.lblCh1RangeUnits3.AutoSize = True
        Me.lblCh1RangeUnits3.Location = New System.Drawing.Point(153, 23)
        Me.lblCh1RangeUnits3.Name = "lblCh1RangeUnits3"
        Me.lblCh1RangeUnits3.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits3.TabIndex = 13
        Me.lblCh1RangeUnits3.Text = "microns"
        '
        'chkInfinite
        '
        Me.chkInfinite.AutoSize = True
        Me.chkInfinite.Checked = True
        Me.chkInfinite.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkInfinite.Location = New System.Drawing.Point(156, 72)
        Me.chkInfinite.Name = "chkInfinite"
        Me.chkInfinite.Size = New System.Drawing.Size(57, 17)
        Me.chkInfinite.TabIndex = 8
        Me.chkInfinite.Text = "Infinite"
        Me.chkInfinite.UseVisualStyleBackColor = True
        '
        'btnStopWaveform
        '
        Me.btnStopWaveform.Location = New System.Drawing.Point(149, 99)
        Me.btnStopWaveform.Name = "btnStopWaveform"
        Me.btnStopWaveform.Size = New System.Drawing.Size(102, 28)
        Me.btnStopWaveform.TabIndex = 6
        Me.btnStopWaveform.Text = "Stop Waveform"
        Me.btnStopWaveform.UseVisualStyleBackColor = True
        '
        'btnStartWaveform
        '
        Me.btnStartWaveform.Location = New System.Drawing.Point(41, 99)
        Me.btnStartWaveform.Name = "btnStartWaveform"
        Me.btnStartWaveform.Size = New System.Drawing.Size(102, 28)
        Me.btnStartWaveform.TabIndex = 5
        Me.btnStartWaveform.Text = "Start Waveform"
        Me.btnStartWaveform.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(34, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Iterations"
        '
        'numIterations
        '
        Me.numIterations.Enabled = False
        Me.numIterations.Location = New System.Drawing.Point(87, 71)
        Me.numIterations.Name = "numIterations"
        Me.numIterations.Size = New System.Drawing.Size(63, 20)
        Me.numIterations.TabIndex = 2
        Me.numIterations.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 47)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Frequency"
        '
        'numFrequency
        '
        Me.numFrequency.DecimalPlaces = 1
        Me.numFrequency.Location = New System.Drawing.Point(87, 45)
        Me.numFrequency.Minimum = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numFrequency.Name = "numFrequency"
        Me.numFrequency.Size = New System.Drawing.Size(63, 20)
        Me.numFrequency.TabIndex = 1
        Me.numFrequency.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Ch1 Amplitude"
        '
        'numAmplitude
        '
        Me.numAmplitude.DecimalPlaces = 3
        Me.numAmplitude.Location = New System.Drawing.Point(87, 19)
        Me.numAmplitude.Name = "numAmplitude"
        Me.numAmplitude.Size = New System.Drawing.Size(63, 20)
        Me.numAmplitude.TabIndex = 0
        Me.numAmplitude.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(842, 324)
        Me.Controls.Add(Me.grpWaveform)
        Me.Controls.Add(Me.grpRecordParam)
        Me.Controls.Add(Me.grpDigitalPosition)
        Me.Controls.Add(Me.grpSensor)
        Me.Controls.Add(Me.grpTrajectory)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.lstDeviceList)
        Me.Controls.Add(Me.btnListDevices)
        Me.Controls.Add(Me.btnDisconnect)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LC.400 Example"
        CType(Me.numDigitalPosition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numMoveSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numVelocity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTrajectory.ResumeLayout(False)
        Me.grpTrajectory.PerformLayout()
        CType(Me.numJerk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numAcceleration, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpSensor.ResumeLayout(False)
        Me.grpSensor.PerformLayout()
        Me.grpDigitalPosition.ResumeLayout(False)
        Me.grpDigitalPosition.PerformLayout()
        Me.grpRecordParam.ResumeLayout(False)
        Me.grpRecordParam.PerformLayout()
        CType(Me.numCyclesPerSample, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numNumberSamples, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpWaveform.ResumeLayout(False)
        Me.grpWaveform.PerformLayout()
        CType(Me.numIterations, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numFrequency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numAmplitude, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnListDevices As System.Windows.Forms.Button
    Friend WithEvents lstDeviceList As System.Windows.Forms.ListBox
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents btnDisconnect As System.Windows.Forms.Button
    Friend WithEvents btnQuerySensor As System.Windows.Forms.Button
    Friend WithEvents txtSensorValue As System.Windows.Forms.TextBox
    Friend WithEvents lblCh1RangeUnits2 As System.Windows.Forms.Label
    Friend WithEvents numDigitalPosition As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents numMoveSize As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents numVelocity As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblCh1RangeUnits4 As System.Windows.Forms.Label
    Friend WithEvents lblCh1RangeUnits As System.Windows.Forms.Label
    Friend WithEvents lblTrajMoveVel As System.Windows.Forms.Label
    Friend WithEvents grpTrajectory As System.Windows.Forms.GroupBox
    Friend WithEvents btnStartTraj As System.Windows.Forms.Button
    Friend WithEvents grpSensor As System.Windows.Forms.GroupBox
    Friend WithEvents grpDigitalPosition As System.Windows.Forms.GroupBox
    Friend WithEvents lblTrajMoveJerk As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents numJerk As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblTrajMoveAccel As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents numAcceleration As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnStopTraj As System.Windows.Forms.Button
    Friend WithEvents tmrCheckTrajectoryState As System.Windows.Forms.Timer
    Friend WithEvents grpRecordParam As System.Windows.Forms.GroupBox
    Friend WithEvents chkRecordTraj As System.Windows.Forms.CheckBox
    Friend WithEvents lblRecTime As System.Windows.Forms.Label
    Friend WithEvents label70 As System.Windows.Forms.Label
    Friend WithEvents numCyclesPerSample As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnSaveToFile As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents numNumberSamples As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnStartRecording As System.Windows.Forms.Button
    Friend WithEvents tmrCheckForRecComplete As System.Windows.Forms.Timer
    Friend WithEvents dlgSaveRecording As System.Windows.Forms.SaveFileDialog
    Friend WithEvents grpWaveform As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblCh1RangeUnits3 As System.Windows.Forms.Label
    Friend WithEvents chkInfinite As System.Windows.Forms.CheckBox
    Friend WithEvents btnStopWaveform As System.Windows.Forms.Button
    Friend WithEvents btnStartWaveform As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents numIterations As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents numFrequency As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents numAmplitude As System.Windows.Forms.NumericUpDown

End Class
