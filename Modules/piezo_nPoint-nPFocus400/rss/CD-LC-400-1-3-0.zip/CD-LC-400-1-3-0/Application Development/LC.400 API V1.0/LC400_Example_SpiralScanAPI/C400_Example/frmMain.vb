﻿Option Explicit On
Option Strict On
Imports System.Text

Public Class frmMain
    Dim mConnected As Boolean
    Dim mConnectionID As Integer
    Dim mUpdatingUI As Boolean 'used in the value changed event for UI controls so that the value isn't sent to the controller when initializing the UI

    Private Sub frmMain_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        If mConnected = True Then
            disconnect()
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listDevices()
    End Sub

    Private Sub btnListDevices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnListDevices.Click
        listDevices()
    End Sub

    Private Sub listDevices()
        Try
            lstDeviceList.Items.Clear()
            Dim success As Integer
            Dim numDevices As Integer
            Dim serialNum As New StringBuilder(16) 'USB Serial Number is a 16 character char array
            Dim description As New StringBuilder(64) 'USB Description is a 64 character char array

            'Determine the number of nPoint devices connected to the PC
            success = LC400API.buildAvailUSB_devList(numDevices)

            'iterate through the device list to retreive the serialnumber and description to populate the listbox control
            If success = 0 And numDevices > 0 Then
                For i As Integer = 0 To numDevices - 1
                    success = LC400API.getAvailUSB_devInfo(i, serialNum, description)
                    If success <> 0 Then
                        Throw New Exception("Error getting device serial number and description")
                    End If
                    lstDeviceList.Items.Add(serialNum.ToString & " - " & description.ToString)
                Next
            End If
            If lstDeviceList.Items.Count = 1 Then
                lstDeviceList.SelectedIndex = 0
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        connect()
    End Sub

    Private Sub connect()
        Try
            Dim success As Integer
            Dim numChannels As Integer
            Dim ch1Range As Single
            Dim ch1DistanceUnits As Integer
            Dim ch1PositionCmd As Single
            Dim ch2Range As Single
            Dim ch2DistanceUnits As Integer
            Dim ch2PositionCmd As Single
            Dim spiralAxis1 As Integer
            Dim spiralAxis2 As Integer
            Dim spiralAxis1Radius As Single
            Dim spiralAxis2Radius As Single
            Dim spiralRevPerSec As Single
            Dim spiralLineSpacing As Single
            Dim spiralRadiusStepVel As Single
            Dim spiralDwellTime As Single

            If lstDeviceList.SelectedIndex = -1 Then
                MsgBox("Please select an FTDI device from the list")
            Else
                success = LC400API.connectUSB(lstDeviceList.SelectedIndex, mConnectionID)
                If success = 0 Then
                    mConnected = True
                    'determine the number of channels in the controller
                    success = LC400API.getNumChannels(mConnectionID, numChannels)
                    If success <> 0 Or numChannels < 1 Then
                        Throw New Exception("Error getting the number of controller channels.")
                    End If
                    If numChannels < 2 Then
                        Throw New Exception("Error - spiral scans require two or more controller channels.")
                    End If
                    'get Ch1 range and distance units
                    success = LC400API.getRange(mConnectionID, 1, ch1Range, ch1DistanceUnits)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch1 travel range.")
                    End If
                    'set the numeric entry UI control minimum and maximum values
                    numCh1DigPosition.Maximum = Convert.ToDecimal(ch1Range / 2)
                    numCh1DigPosition.Minimum = Convert.ToDecimal(ch1Range / 2 * -1)
                    numRadius1.Maximum = Convert.ToDecimal(ch1Range)
                    numLineSpacing.Maximum = Convert.ToDecimal(ch1Range)

                    'query current Ch1 Digital Position Command and initialize the UI
                    success = LC400API.getDigPosition(mConnectionID, 1, ch1PositionCmd)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch1 digital position command.")
                    End If
                    mUpdatingUI = True
                    If ch1PositionCmd > numCh1DigPosition.Maximum Then
                        numCh1DigPosition.Value = numCh1DigPosition.Maximum
                        MsgBox("Ch1 Digital Position Command value is greater than the calibrated stage travel maximum.", MsgBoxStyle.Exclamation, "Error")
                    ElseIf ch1PositionCmd < numCh1DigPosition.Minimum Then
                        numCh1DigPosition.Value = numCh1DigPosition.Minimum
                        MsgBox("Ch1 Digital Position Command value is less than the calibrated stage travel minimum.", MsgBoxStyle.Exclamation, "Error")
                    Else
                        numCh1DigPosition.Value = Convert.ToDecimal(ch1PositionCmd)
                    End If

                    'get Ch2 range and distance units
                    success = LC400API.getRange(mConnectionID, 2, ch2Range, ch2DistanceUnits)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch2 travel range.")
                    End If
                    'set the numeric entry UI control minimum and maximum values
                    numCh2DigPosition.Maximum = Convert.ToDecimal(ch2Range / 2)
                    numCh2DigPosition.Minimum = Convert.ToDecimal(ch2Range / 2 * -1)
                    numRadius2.Maximum = Convert.ToDecimal(ch2Range)

                    'query current Ch2 Digital Position Command and initialize the UI
                    success = LC400API.getDigPosition(mConnectionID, 2, ch2PositionCmd)
                    If success <> 0 Then
                        Throw New Exception("Error getting Ch2 digital position command.")
                    End If
                    If ch2PositionCmd > numCh2DigPosition.Maximum Then
                        numCh2DigPosition.Value = numCh2DigPosition.Maximum
                        MsgBox("Ch2 Digital Position Command value is greater than the calibrated stage travel maximum.", MsgBoxStyle.Exclamation, "Error")
                    ElseIf ch2PositionCmd < numCh2DigPosition.Minimum Then
                        numCh2DigPosition.Value = numCh2DigPosition.Minimum
                        MsgBox("Ch2 Digital Position Command value is less than the calibrated stage travel minimum.", MsgBoxStyle.Exclamation, "Error")
                    Else
                        numCh2DigPosition.Value = Convert.ToDecimal(ch2PositionCmd)
                    End If

                    'get spiral parameters to initialize the UI. Spiral Axis1 and Spiral Axis2 may be different that Ch1 and Ch2, however this example hard codes them to Ch1 and Ch2 to keep the UI simple
                    success = LC400API.getSpiralParameters(mConnectionID, spiralAxis1, spiralAxis2, spiralAxis1Radius, spiralAxis2Radius, spiralLineSpacing, spiralRevPerSec, spiralRadiusStepVel, spiralDwellTime)
                    If success <> 0 Then
                        Throw New Exception("Error getting spiral parameters.")
                    End If
                    If spiralAxis1Radius > numRadius1.Maximum Then
                        numRadius1.Value = numRadius1.Maximum
                    ElseIf spiralAxis1Radius < numRadius1.Minimum Then
                        numRadius1.Value = numRadius1.Minimum
                    Else
                        numRadius1.Value = Convert.ToDecimal(spiralAxis1Radius)
                    End If

                    If spiralAxis2Radius > numRadius2.Maximum Then
                        numRadius2.Value = numRadius2.Maximum
                    ElseIf spiralAxis2Radius < numRadius2.Minimum Then
                        numRadius2.Value = numRadius2.Minimum
                    Else
                        numRadius2.Value = Convert.ToDecimal(spiralAxis2Radius)
                    End If

                    If spiralLineSpacing > numLineSpacing.Maximum Then
                        numLineSpacing.Value = numLineSpacing.Maximum
                    ElseIf spiralLineSpacing < numLineSpacing.Minimum Then
                        numLineSpacing.Value = numLineSpacing.Minimum
                    Else
                        numLineSpacing.Value = Convert.ToDecimal(spiralLineSpacing)
                    End If

                    If spiralRevPerSec > numRPS.Maximum Then
                        numRPS.Value = numRPS.Maximum
                    ElseIf spiralRevPerSec < numRPS.Minimum Then
                        numRPS.Value = numRPS.Minimum
                    Else
                        numRPS.Value = Convert.ToDecimal(spiralRevPerSec)
                    End If

                    If spiralRadiusStepVel > numStepVelocity.Maximum Then
                        numStepVelocity.Value = numStepVelocity.Maximum
                    ElseIf spiralRadiusStepVel < numStepVelocity.Minimum Then
                        numStepVelocity.Value = numStepVelocity.Minimum
                    Else
                        numStepVelocity.Value = Convert.ToDecimal(spiralRadiusStepVel)
                    End If

                    If spiralDwellTime > numDwell.Maximum Then
                        numDwell.Value = numDwell.Maximum
                    ElseIf spiralDwellTime < numDwell.Minimum Then
                        numDwell.Value = numDwell.Minimum
                    Else
                        numDwell.Value = Convert.ToDecimal(spiralDwellTime)
                    End If

                    'Starting at the center vs starting at the maximum radius is not saved in the controller.  The last scan type used could be saved on the PC using "my.settings" in VB.NET

                    mUpdatingUI = False
                    btnConnect.Visible = False
                    btnDisconnect.Visible = True
                    grpStaticPositions.Visible = True
                    grpSpiral.Visible = True
                    grpRecordParam.Visible = True
                Else
                    mConnected = False
                    Throw New Exception("Error connecting to the selected device")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            mUpdatingUI = False
        End Try
    End Sub

    Private Sub lstDeviceList_DoubleClick(sender As Object, e As System.EventArgs) Handles lstDeviceList.DoubleClick
        connect()
    End Sub

    Private Sub btnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisconnect.Click
        disconnect()
    End Sub

    Private Sub disconnect()
        Try
            mConnected = False
            btnConnect.Visible = True
            btnDisconnect.Visible = False
            grpStaticPositions.Visible = False
            grpSpiral.Visible = False
            grpRecordParam.Visible = False
            txtCh1SensorValue.Text = ""
            txtCh2SensorValue.Text = ""
            Dim success As Integer = LC400API.disconnect(mConnectionID)
            If success <> 0 Then
                Throw New System.Exception("An error occurred when closing the USB connection.")
            End If
            listDevices() 'update list of USB devices available to connect to
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub numCh1DigPosition_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numCh1DigPosition.ValueChanged
        If Not mUpdatingUI Then
            Try
                Dim success As Integer = LC400API.setDigPosition(mConnectionID, 1, numCh1DigPosition.Value)
                If success <> 0 Then
                    Throw New System.Exception("An error occurred when sending the digital position command.")
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            End Try
        End If
    End Sub

    Private Sub numCh2DigPosition_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numCh2DigPosition.ValueChanged
        If Not mUpdatingUI Then
            Try
                Dim success As Integer = LC400API.setDigPosition(mConnectionID, 2, numCh2DigPosition.Value)
                If success <> 0 Then
                    Throw New System.Exception("An error occurred when sending the digital position command.")
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            End Try
        End If
    End Sub

    Private Sub btnQuerySensor_Click(sender As System.Object, e As System.EventArgs) Handles btnQuerySensor.Click
        Try
            'query the sensor reading, populate the text box with a scaled value
            Dim ch1SensorReading As Single
            Dim ch2SensorReading As Single
            Dim success As Integer = LC400API.getSensorMonitor(mConnectionID, 1, ch1SensorReading)
            If success = 0 Then
                txtCh1SensorValue.Text = ch1SensorReading.ToString("0.000")
            Else
                Throw New System.Exception("An error occurred when reading the sensor monitor value.")
            End If
            success = LC400API.getSensorMonitor(mConnectionID, 2, ch2SensorReading)
            If success = 0 Then
                txtCh2SensorValue.Text = ch2SensorReading.ToString("0.000")
            Else
                Throw New System.Exception("An error occurred when reading the sensor monitor value.")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub tmrCheckSpiralScanState_Tick(sender As System.Object, e As System.EventArgs) Handles tmrCheckSpiralScanState.Tick
        Try
            Dim spiralStatus As Integer
            Dim success As Integer = LC400API.getSpiralScanStatus(mConnectionID, spiralStatus)
            If spiralStatus = 0 Then
                'spiral scan has completed, disable query timer and enable the start button
                tmrCheckSpiralScanState.Enabled = False
                btnStartSpiral.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            tmrCheckSpiralScanState.Enabled = False
        End Try
    End Sub

    Private Sub btnStartRecording_Click(sender As System.Object, e As System.EventArgs) Handles btnStartRecording.Click
        startRecording()
    End Sub

    Private Sub startRecording()
        Try
            btnStartRecording.Enabled = False
            Dim success As Integer = LC400API.setRecPointer(mConnectionID, 0, 1, 2) 'set the recording pointer for buffer0 to ch1 position command
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            success = LC400API.setRecPointer(mConnectionID, 1, 1, 1) 'set the recording pointer for buffer1 to ch1 sensor monitor
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            success = LC400API.setRecPointer(mConnectionID, 2, 2, 2) 'set the recording pointer for buffer2 to ch2 position command
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            success = LC400API.setRecPointer(mConnectionID, 3, 2, 1) 'set the recording pointer for buffer3 to ch2 sensor monitor
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            success = LC400API.setRecPointer(mConnectionID, 4, 1, 4) 'set the recording pointer for Ch1 BNC Analog Input for applications that record signal strength vs. XY position
            If success <> 0 Then
                Throw New Exception("An error occurred setting the recording parameters")
            End If
            'set the other buffers for no recording
            For i As Integer = 5 To 7
                success = LC400API.setRecPointer(mConnectionID, i, 0, 0) 'set no recording for buffer2 through buffer7
                If success <> 0 Then
                    Throw New Exception("An error occurred setting the recording parameters")
                End If
            Next
           
            'start the recording
            success = LC400API.startRec(mConnectionID, Convert.ToInt32(numNumberSamples.Value), Convert.ToInt32(numCyclesPerSample.Value))
            If success <> 0 Then
                Throw New Exception("An error occurred starting the recording function")
            End If
            tmrCheckForRecComplete.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub tmrCheckForRecComplete_Tick(sender As System.Object, e As System.EventArgs) Handles tmrCheckForRecComplete.Tick
        Try
            Dim recStatus As Integer
            Dim index As Integer
            Dim success As Integer = LC400API.getRecStatus(mConnectionID, recStatus, index)
            If success <> 0 Then
                Throw New Exception("An error occurred when reading the recording status")
            End If
            If recStatus = 0 Then 'recording is completed
                tmrCheckForRecComplete.Enabled = False
                btnStartRecording.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            tmrCheckForRecComplete.Enabled = False
        End Try
    End Sub

    Private Sub btnSaveToFile_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveToFile.Click
        Dim fileStreamOpen As Boolean = False
        Dim numSamples As Integer = Convert.ToInt32(Math.Round(numNumberSamples.Value))
        Dim time As Single = 0
        Dim timeIncrement As Single
        'determine time between samples based on the number of control loop cycles per sample value
        timeIncrement = Convert.ToSingle(Math.Round(numCyclesPerSample.Value, 0) * 0.000024)

        'read buffers for Ch1 Position Cmd and Ch1 Sensor Monitor values
        Dim ch1PosCmdBuffer(numSamples - 1) As Single
        Dim ch1SensorMonBuffer(numSamples - 1) As Single
        Dim ch2PosCmdBuffer(numSamples - 1) As Single
        Dim ch2SensorMonBuffer(numSamples - 1) As Single
        Dim ch1AIBNC_buffer(numSamples - 1) As Single
        Dim success As Integer = LC400API.getScaledRecBuffer(mConnectionID, 0, ch1PosCmdBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        success = LC400API.getScaledRecBuffer(mConnectionID, 1, ch1SensorMonBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        success = LC400API.getScaledRecBuffer(mConnectionID, 2, ch2PosCmdBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        success = LC400API.getScaledRecBuffer(mConnectionID, 3, ch2SensorMonBuffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        success = LC400API.getScaledRecBuffer(mConnectionID, 4, ch1AIBNC_buffer, numSamples)
        If success <> 0 Then
            Throw New Exception("Error reading a recording buffer")
        End If
        'open a save file dialog for the user to choose a file path
        Try
            Dim dialogReturn As Integer
            dlgSaveRecording.Filter = "CSV Files|*.csv|All Files|*.*"
            dialogReturn = dlgSaveRecording.ShowDialog
            If dialogReturn = DialogResult.Cancel Then
                Exit Sub
            Else
                Dim fileStream As System.IO.StreamWriter = New System.IO.StreamWriter(dlgSaveRecording.FileName)
                fileStreamOpen = True
                Try
                    'write the column header row
                    fileStream.Write("Time (seconds),Ch1 Position Cmd (microns),Ch1 Sensor Mon (microns),Ch2 Position Cmd (microns),Ch2 Sensor Mon (microns),Ch1 AI BNC (Volts)" & vbCrLf)
                    'write the data rows
                    For i = 0 To numSamples - 1
                        fileStream.Write(time.ToString & "," & ch1PosCmdBuffer(i).ToString & "," & ch1SensorMonBuffer(i).ToString & "," & ch2PosCmdBuffer(i).ToString & "," & _
                                         ch2SensorMonBuffer(i).ToString & "," & ch1AIBNC_buffer(i).ToString & vbCrLf)
                        time += timeIncrement
                    Next
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
                Finally
                    If fileStreamOpen = True Then
                        fileStream.Close()
                    End If
                End Try
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Private Sub numNumberSamples_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numNumberSamples.ValueChanged
        lblRecTime.Text = (Math.Round(numNumberSamples.Value, 0) * Math.Round(numCyclesPerSample.Value, 0) * 0.000024).ToString("0.000000") & " sec"
    End Sub

    Private Sub numCyclesPerSample_ValueChanged(sender As System.Object, e As System.EventArgs) Handles numCyclesPerSample.ValueChanged
        lblRecTime.Text = (Math.Round(numNumberSamples.Value, 0) * Math.Round(numCyclesPerSample.Value, 0) * 0.000024).ToString("0.000000") & " sec"
    End Sub

    Private Sub btnStartSpiral_Click(sender As System.Object, e As System.EventArgs) Handles btnStartSpiral.Click
        Try
            btnStartSpiral.Enabled = False
            Dim success As Integer
            success = LC400API.setSpiralParameters(mConnectionID, 1, 2, numRadius1.Value, numRadius2.Value, numLineSpacing.Value, numRPS.Value, numStepVelocity.Value, numDwell.Value)
            If success <> 0 Then
                Throw New Exception("Error setting spiral scan parameters")
            End If
            'Set the frame axis to 3 if the controller has 2 channels, a value of zero causes a problem with the DSP algorithm
            'Set the frame step size to zero for a two channel only spiral scan
            'Set the number of frames value to 1 for 1 spiral scan iteration
            success = LC400API.setSpiralFrameParameters(mConnectionID, 3, 0, 1)
            If success <> 0 Then
                Throw New Exception("Error setting spiral scan frame parameters")
            End If
            'if the checkbox to start the recording when starting the spiral scan is checked, start the recording immediately prior to starting the spiral scan
            If chkRecordSpiral.Checked = True Then
                startRecording()
            End If
            'start the spiral scan with a value of 1 or 2 depending on if the scan is increasing or decreasing amplitude
            If optIncreasing.Checked = True Then
                success = LC400API.startSpiralScan(mConnectionID, 2)
            Else
                success = LC400API.startSpiralScan(mConnectionID, 1)
            End If
            If success <> 0 Then
                Throw New Exception("Error starting the spiral scan")
            End If
            tmrCheckSpiralScanState.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
            btnStartSpiral.Enabled = True
        End Try
    End Sub

    Private Sub btnStopSpiral_Click(sender As System.Object, e As System.EventArgs) Handles btnStopSpiral.Click
        Try
            Dim success As Integer = LC400API.stopSpiralScan(mConnectionID)
            If success <> 0 Then
                Throw New Exception("Error stopping the spiral scan")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub
End Class
