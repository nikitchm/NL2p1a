﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnListDevices = New System.Windows.Forms.Button()
        Me.lstDeviceList = New System.Windows.Forms.ListBox()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.btnDisconnect = New System.Windows.Forms.Button()
        Me.tmrCheckSpiralScanState = New System.Windows.Forms.Timer(Me.components)
        Me.grpRecordParam = New System.Windows.Forms.GroupBox()
        Me.chkRecordSpiral = New System.Windows.Forms.CheckBox()
        Me.lblRecTime = New System.Windows.Forms.Label()
        Me.label70 = New System.Windows.Forms.Label()
        Me.numCyclesPerSample = New System.Windows.Forms.NumericUpDown()
        Me.btnSaveToFile = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.numNumberSamples = New System.Windows.Forms.NumericUpDown()
        Me.btnStartRecording = New System.Windows.Forms.Button()
        Me.tmrCheckForRecComplete = New System.Windows.Forms.Timer(Me.components)
        Me.dlgSaveRecording = New System.Windows.Forms.SaveFileDialog()
        Me.grpStaticPositions = New System.Windows.Forms.GroupBox()
        Me.numCh2DigPosition = New System.Windows.Forms.NumericUpDown()
        Me.numCh1DigPosition = New System.Windows.Forms.NumericUpDown()
        Me.lblCh2RangeUnits2 = New System.Windows.Forms.Label()
        Me.lblCh2RangeUnits1 = New System.Windows.Forms.Label()
        Me.lblCh2SensorValue = New System.Windows.Forms.Label()
        Me.txtCh2SensorValue = New System.Windows.Forms.TextBox()
        Me.lblCh2DigitalPosCmd = New System.Windows.Forms.Label()
        Me.lblCh1RangeUnits2 = New System.Windows.Forms.Label()
        Me.lblCh1RangeUnits1 = New System.Windows.Forms.Label()
        Me.lblCh1SensorValue = New System.Windows.Forms.Label()
        Me.btnQuerySensor = New System.Windows.Forms.Button()
        Me.txtCh1SensorValue = New System.Windows.Forms.TextBox()
        Me.lblCh1DigitalPosCmd = New System.Windows.Forms.Label()
        Me.grpSpiral = New System.Windows.Forms.GroupBox()
        Me.btnStopSpiral = New System.Windows.Forms.Button()
        Me.btnStartSpiral = New System.Windows.Forms.Button()
        Me.optDecreasing = New System.Windows.Forms.RadioButton()
        Me.optIncreasing = New System.Windows.Forms.RadioButton()
        Me.lblVelocity = New System.Windows.Forms.Label()
        Me.numStepVelocity = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.numDwell = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.numRPS = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblRadius2 = New System.Windows.Forms.Label()
        Me.numRadius2 = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblLineSpacing = New System.Windows.Forms.Label()
        Me.lblRadius1 = New System.Windows.Forms.Label()
        Me.numLineSpacing = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.numRadius1 = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grpRecordParam.SuspendLayout()
        CType(Me.numCyclesPerSample, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numNumberSamples, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpStaticPositions.SuspendLayout()
        CType(Me.numCh2DigPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numCh1DigPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpSpiral.SuspendLayout()
        CType(Me.numStepVelocity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numDwell, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numRPS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numRadius2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numLineSpacing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numRadius1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnListDevices
        '
        Me.btnListDevices.Location = New System.Drawing.Point(12, 152)
        Me.btnListDevices.Name = "btnListDevices"
        Me.btnListDevices.Size = New System.Drawing.Size(165, 37)
        Me.btnListDevices.TabIndex = 1
        Me.btnListDevices.Text = "List nPoint Devices"
        Me.btnListDevices.UseVisualStyleBackColor = True
        '
        'lstDeviceList
        '
        Me.lstDeviceList.FormattingEnabled = True
        Me.lstDeviceList.Location = New System.Drawing.Point(12, 12)
        Me.lstDeviceList.Name = "lstDeviceList"
        Me.lstDeviceList.Size = New System.Drawing.Size(165, 134)
        Me.lstDeviceList.TabIndex = 0
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(12, 197)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(165, 37)
        Me.btnConnect.TabIndex = 2
        Me.btnConnect.Text = "Connect to Selected Device"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Location = New System.Drawing.Point(12, 197)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(165, 37)
        Me.btnDisconnect.TabIndex = 3
        Me.btnDisconnect.Text = "Disconnect"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        Me.btnDisconnect.Visible = False
        '
        'tmrCheckSpiralScanState
        '
        '
        'grpRecordParam
        '
        Me.grpRecordParam.Controls.Add(Me.chkRecordSpiral)
        Me.grpRecordParam.Controls.Add(Me.lblRecTime)
        Me.grpRecordParam.Controls.Add(Me.label70)
        Me.grpRecordParam.Controls.Add(Me.numCyclesPerSample)
        Me.grpRecordParam.Controls.Add(Me.btnSaveToFile)
        Me.grpRecordParam.Controls.Add(Me.Label14)
        Me.grpRecordParam.Controls.Add(Me.Label15)
        Me.grpRecordParam.Controls.Add(Me.numNumberSamples)
        Me.grpRecordParam.Controls.Add(Me.btnStartRecording)
        Me.grpRecordParam.Location = New System.Drawing.Point(656, 12)
        Me.grpRecordParam.Name = "grpRecordParam"
        Me.grpRecordParam.Size = New System.Drawing.Size(339, 141)
        Me.grpRecordParam.TabIndex = 6
        Me.grpRecordParam.TabStop = False
        Me.grpRecordParam.Text = "Rec Ch1 Cmd, Ch1 Sensor, Ch2 Cmd, Ch2 Sensor, Ch1 AI BNC"
        Me.grpRecordParam.Visible = False
        '
        'chkRecordSpiral
        '
        Me.chkRecordSpiral.AutoSize = True
        Me.chkRecordSpiral.Checked = True
        Me.chkRecordSpiral.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRecordSpiral.Location = New System.Drawing.Point(34, 76)
        Me.chkRecordSpiral.Name = "chkRecordSpiral"
        Me.chkRecordSpiral.Size = New System.Drawing.Size(222, 17)
        Me.chkRecordSpiral.TabIndex = 2
        Me.chkRecordSpiral.Text = "Start recording when spiral scan is started"
        Me.chkRecordSpiral.UseVisualStyleBackColor = True
        '
        'lblRecTime
        '
        Me.lblRecTime.AutoSize = True
        Me.lblRecTime.Location = New System.Drawing.Point(249, 22)
        Me.lblRecTime.Name = "lblRecTime"
        Me.lblRecTime.Size = New System.Drawing.Size(72, 13)
        Me.lblRecTime.TabIndex = 36
        Me.lblRecTime.Text = "0.720000 sec"
        '
        'label70
        '
        Me.label70.AutoSize = True
        Me.label70.Location = New System.Drawing.Point(165, 22)
        Me.label70.Name = "label70"
        Me.label70.Size = New System.Drawing.Size(80, 13)
        Me.label70.TabIndex = 35
        Me.label70.Text = "Record Time = "
        '
        'numCyclesPerSample
        '
        Me.numCyclesPerSample.Location = New System.Drawing.Point(93, 48)
        Me.numCyclesPerSample.Maximum = New Decimal(New Integer() {83333, 0, 0, 0})
        Me.numCyclesPerSample.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numCyclesPerSample.Name = "numCyclesPerSample"
        Me.numCyclesPerSample.Size = New System.Drawing.Size(56, 20)
        Me.numCyclesPerSample.TabIndex = 1
        Me.numCyclesPerSample.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numCyclesPerSample.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Location = New System.Drawing.Point(148, 100)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(102, 30)
        Me.btnSaveToFile.TabIndex = 4
        Me.btnSaveToFile.Text = "Save to File"
        Me.btnSaveToFile.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 50)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 13)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "Cycles/Sample:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(15, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(75, 13)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Num Samples:"
        '
        'numNumberSamples
        '
        Me.numNumberSamples.Location = New System.Drawing.Point(93, 20)
        Me.numNumberSamples.Maximum = New Decimal(New Integer() {83333, 0, 0, 0})
        Me.numNumberSamples.Name = "numNumberSamples"
        Me.numNumberSamples.Size = New System.Drawing.Size(56, 20)
        Me.numNumberSamples.TabIndex = 0
        Me.numNumberSamples.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numNumberSamples.Value = New Decimal(New Integer() {30000, 0, 0, 0})
        '
        'btnStartRecording
        '
        Me.btnStartRecording.Location = New System.Drawing.Point(34, 100)
        Me.btnStartRecording.Name = "btnStartRecording"
        Me.btnStartRecording.Size = New System.Drawing.Size(102, 30)
        Me.btnStartRecording.TabIndex = 3
        Me.btnStartRecording.Text = "Start Recording"
        Me.btnStartRecording.UseVisualStyleBackColor = True
        '
        'tmrCheckForRecComplete
        '
        '
        'grpStaticPositions
        '
        Me.grpStaticPositions.Controls.Add(Me.numCh2DigPosition)
        Me.grpStaticPositions.Controls.Add(Me.numCh1DigPosition)
        Me.grpStaticPositions.Controls.Add(Me.lblCh2RangeUnits2)
        Me.grpStaticPositions.Controls.Add(Me.lblCh2RangeUnits1)
        Me.grpStaticPositions.Controls.Add(Me.lblCh2SensorValue)
        Me.grpStaticPositions.Controls.Add(Me.txtCh2SensorValue)
        Me.grpStaticPositions.Controls.Add(Me.lblCh2DigitalPosCmd)
        Me.grpStaticPositions.Controls.Add(Me.lblCh1RangeUnits2)
        Me.grpStaticPositions.Controls.Add(Me.lblCh1RangeUnits1)
        Me.grpStaticPositions.Controls.Add(Me.lblCh1SensorValue)
        Me.grpStaticPositions.Controls.Add(Me.btnQuerySensor)
        Me.grpStaticPositions.Controls.Add(Me.txtCh1SensorValue)
        Me.grpStaticPositions.Controls.Add(Me.lblCh1DigitalPosCmd)
        Me.grpStaticPositions.Location = New System.Drawing.Point(194, 12)
        Me.grpStaticPositions.Name = "grpStaticPositions"
        Me.grpStaticPositions.Size = New System.Drawing.Size(163, 250)
        Me.grpStaticPositions.TabIndex = 4
        Me.grpStaticPositions.TabStop = False
        Me.grpStaticPositions.Text = "Static Digital Position"
        Me.grpStaticPositions.Visible = False
        '
        'numCh2DigPosition
        '
        Me.numCh2DigPosition.DecimalPlaces = 3
        Me.numCh2DigPosition.Location = New System.Drawing.Point(9, 130)
        Me.numCh2DigPosition.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.numCh2DigPosition.Name = "numCh2DigPosition"
        Me.numCh2DigPosition.Size = New System.Drawing.Size(75, 20)
        Me.numCh2DigPosition.TabIndex = 2
        '
        'numCh1DigPosition
        '
        Me.numCh1DigPosition.DecimalPlaces = 3
        Me.numCh1DigPosition.Location = New System.Drawing.Point(9, 37)
        Me.numCh1DigPosition.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.numCh1DigPosition.Name = "numCh1DigPosition"
        Me.numCh1DigPosition.Size = New System.Drawing.Size(75, 20)
        Me.numCh1DigPosition.TabIndex = 0
        '
        'lblCh2RangeUnits2
        '
        Me.lblCh2RangeUnits2.AutoSize = True
        Me.lblCh2RangeUnits2.Location = New System.Drawing.Point(90, 172)
        Me.lblCh2RangeUnits2.Name = "lblCh2RangeUnits2"
        Me.lblCh2RangeUnits2.Size = New System.Drawing.Size(43, 13)
        Me.lblCh2RangeUnits2.TabIndex = 63
        Me.lblCh2RangeUnits2.Text = "microns"
        '
        'lblCh2RangeUnits1
        '
        Me.lblCh2RangeUnits1.AutoSize = True
        Me.lblCh2RangeUnits1.Location = New System.Drawing.Point(90, 132)
        Me.lblCh2RangeUnits1.Name = "lblCh2RangeUnits1"
        Me.lblCh2RangeUnits1.Size = New System.Drawing.Size(43, 13)
        Me.lblCh2RangeUnits1.TabIndex = 62
        Me.lblCh2RangeUnits1.Text = "microns"
        '
        'lblCh2SensorValue
        '
        Me.lblCh2SensorValue.AutoSize = True
        Me.lblCh2SensorValue.Location = New System.Drawing.Point(6, 153)
        Me.lblCh2SensorValue.Name = "lblCh2SensorValue"
        Me.lblCh2SensorValue.Size = New System.Drawing.Size(92, 13)
        Me.lblCh2SensorValue.TabIndex = 61
        Me.lblCh2SensorValue.Text = "Ch2 Sensor Value"
        '
        'txtCh2SensorValue
        '
        Me.txtCh2SensorValue.Location = New System.Drawing.Point(9, 169)
        Me.txtCh2SensorValue.Name = "txtCh2SensorValue"
        Me.txtCh2SensorValue.ReadOnly = True
        Me.txtCh2SensorValue.Size = New System.Drawing.Size(75, 20)
        Me.txtCh2SensorValue.TabIndex = 3
        '
        'lblCh2DigitalPosCmd
        '
        Me.lblCh2DigitalPosCmd.AutoSize = True
        Me.lblCh2DigitalPosCmd.Location = New System.Drawing.Point(6, 113)
        Me.lblCh2DigitalPosCmd.Name = "lblCh2DigitalPosCmd"
        Me.lblCh2DigitalPosCmd.Size = New System.Drawing.Size(148, 13)
        Me.lblCh2DigitalPosCmd.TabIndex = 60
        Me.lblCh2DigitalPosCmd.Text = "Ch2 Digital Position Command"
        '
        'lblCh1RangeUnits2
        '
        Me.lblCh1RangeUnits2.AutoSize = True
        Me.lblCh1RangeUnits2.Location = New System.Drawing.Point(90, 79)
        Me.lblCh1RangeUnits2.Name = "lblCh1RangeUnits2"
        Me.lblCh1RangeUnits2.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits2.TabIndex = 59
        Me.lblCh1RangeUnits2.Text = "microns"
        '
        'lblCh1RangeUnits1
        '
        Me.lblCh1RangeUnits1.AutoSize = True
        Me.lblCh1RangeUnits1.Location = New System.Drawing.Point(90, 39)
        Me.lblCh1RangeUnits1.Name = "lblCh1RangeUnits1"
        Me.lblCh1RangeUnits1.Size = New System.Drawing.Size(43, 13)
        Me.lblCh1RangeUnits1.TabIndex = 58
        Me.lblCh1RangeUnits1.Text = "microns"
        '
        'lblCh1SensorValue
        '
        Me.lblCh1SensorValue.AutoSize = True
        Me.lblCh1SensorValue.Location = New System.Drawing.Point(6, 60)
        Me.lblCh1SensorValue.Name = "lblCh1SensorValue"
        Me.lblCh1SensorValue.Size = New System.Drawing.Size(92, 13)
        Me.lblCh1SensorValue.TabIndex = 57
        Me.lblCh1SensorValue.Text = "Ch1 Sensor Value"
        '
        'btnQuerySensor
        '
        Me.btnQuerySensor.Location = New System.Drawing.Point(9, 200)
        Me.btnQuerySensor.Name = "btnQuerySensor"
        Me.btnQuerySensor.Size = New System.Drawing.Size(119, 39)
        Me.btnQuerySensor.TabIndex = 4
        Me.btnQuerySensor.Text = "Query Ch1 and Ch2 Sensor Values"
        Me.btnQuerySensor.UseVisualStyleBackColor = True
        '
        'txtCh1SensorValue
        '
        Me.txtCh1SensorValue.Location = New System.Drawing.Point(9, 76)
        Me.txtCh1SensorValue.Name = "txtCh1SensorValue"
        Me.txtCh1SensorValue.ReadOnly = True
        Me.txtCh1SensorValue.Size = New System.Drawing.Size(75, 20)
        Me.txtCh1SensorValue.TabIndex = 1
        '
        'lblCh1DigitalPosCmd
        '
        Me.lblCh1DigitalPosCmd.AutoSize = True
        Me.lblCh1DigitalPosCmd.Location = New System.Drawing.Point(6, 20)
        Me.lblCh1DigitalPosCmd.Name = "lblCh1DigitalPosCmd"
        Me.lblCh1DigitalPosCmd.Size = New System.Drawing.Size(148, 13)
        Me.lblCh1DigitalPosCmd.TabIndex = 56
        Me.lblCh1DigitalPosCmd.Text = "Ch1 Digital Position Command"
        '
        'grpSpiral
        '
        Me.grpSpiral.Controls.Add(Me.btnStopSpiral)
        Me.grpSpiral.Controls.Add(Me.btnStartSpiral)
        Me.grpSpiral.Controls.Add(Me.optDecreasing)
        Me.grpSpiral.Controls.Add(Me.optIncreasing)
        Me.grpSpiral.Controls.Add(Me.lblVelocity)
        Me.grpSpiral.Controls.Add(Me.numStepVelocity)
        Me.grpSpiral.Controls.Add(Me.Label16)
        Me.grpSpiral.Controls.Add(Me.Label13)
        Me.grpSpiral.Controls.Add(Me.numDwell)
        Me.grpSpiral.Controls.Add(Me.Label1)
        Me.grpSpiral.Controls.Add(Me.numRPS)
        Me.grpSpiral.Controls.Add(Me.Label3)
        Me.grpSpiral.Controls.Add(Me.lblRadius2)
        Me.grpSpiral.Controls.Add(Me.numRadius2)
        Me.grpSpiral.Controls.Add(Me.Label12)
        Me.grpSpiral.Controls.Add(Me.lblLineSpacing)
        Me.grpSpiral.Controls.Add(Me.lblRadius1)
        Me.grpSpiral.Controls.Add(Me.numLineSpacing)
        Me.grpSpiral.Controls.Add(Me.Label5)
        Me.grpSpiral.Controls.Add(Me.numRadius1)
        Me.grpSpiral.Controls.Add(Me.Label4)
        Me.grpSpiral.Location = New System.Drawing.Point(363, 12)
        Me.grpSpiral.Name = "grpSpiral"
        Me.grpSpiral.Size = New System.Drawing.Size(287, 250)
        Me.grpSpiral.TabIndex = 5
        Me.grpSpiral.TabStop = False
        Me.grpSpiral.Text = "Ch1 and Ch2 Single Spiral Scan"
        Me.grpSpiral.Visible = False
        '
        'btnStopSpiral
        '
        Me.btnStopSpiral.Location = New System.Drawing.Point(149, 202)
        Me.btnStopSpiral.Name = "btnStopSpiral"
        Me.btnStopSpiral.Size = New System.Drawing.Size(102, 30)
        Me.btnStopSpiral.TabIndex = 9
        Me.btnStopSpiral.Text = "Stop Spiral Scan"
        Me.btnStopSpiral.UseVisualStyleBackColor = True
        '
        'btnStartSpiral
        '
        Me.btnStartSpiral.Location = New System.Drawing.Point(35, 202)
        Me.btnStartSpiral.Name = "btnStartSpiral"
        Me.btnStartSpiral.Size = New System.Drawing.Size(102, 30)
        Me.btnStartSpiral.TabIndex = 8
        Me.btnStartSpiral.Text = "Start Spiral Scan"
        Me.btnStartSpiral.UseVisualStyleBackColor = True
        '
        'optDecreasing
        '
        Me.optDecreasing.AutoSize = True
        Me.optDecreasing.Location = New System.Drawing.Point(134, 179)
        Me.optDecreasing.Name = "optDecreasing"
        Me.optDecreasing.Size = New System.Drawing.Size(118, 17)
        Me.optDecreasing.TabIndex = 7
        Me.optDecreasing.Text = "Start at Max Radius"
        Me.optDecreasing.UseVisualStyleBackColor = True
        '
        'optIncreasing
        '
        Me.optIncreasing.AutoSize = True
        Me.optIncreasing.Checked = True
        Me.optIncreasing.Location = New System.Drawing.Point(35, 179)
        Me.optIncreasing.Name = "optIncreasing"
        Me.optIncreasing.Size = New System.Drawing.Size(93, 17)
        Me.optIncreasing.TabIndex = 6
        Me.optIncreasing.TabStop = True
        Me.optIncreasing.Text = "Start at Center"
        Me.optIncreasing.UseVisualStyleBackColor = True
        '
        'lblVelocity
        '
        Me.lblVelocity.AutoSize = True
        Me.lblVelocity.Location = New System.Drawing.Point(203, 125)
        Me.lblVelocity.Name = "lblVelocity"
        Me.lblVelocity.Size = New System.Drawing.Size(61, 13)
        Me.lblVelocity.TabIndex = 76
        Me.lblVelocity.Text = "microns/ms"
        '
        'numStepVelocity
        '
        Me.numStepVelocity.DecimalPlaces = 3
        Me.numStepVelocity.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numStepVelocity.Location = New System.Drawing.Point(134, 123)
        Me.numStepVelocity.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numStepVelocity.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.numStepVelocity.Name = "numStepVelocity"
        Me.numStepVelocity.Size = New System.Drawing.Size(65, 20)
        Me.numStepVelocity.TabIndex = 4
        Me.numStepVelocity.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(23, 125)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(105, 13)
        Me.Label16.TabIndex = 75
        Me.Label16.Text = "Radius Step Velocity"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(203, 151)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(20, 13)
        Me.Label13.TabIndex = 74
        Me.Label13.Text = "ms"
        '
        'numDwell
        '
        Me.numDwell.Location = New System.Drawing.Point(134, 149)
        Me.numDwell.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.numDwell.Name = "numDwell"
        Me.numDwell.Size = New System.Drawing.Size(65, 20)
        Me.numDwell.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 151)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 73
        Me.Label1.Text = "Dwell Time"
        '
        'numRPS
        '
        Me.numRPS.DecimalPlaces = 2
        Me.numRPS.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numRPS.Location = New System.Drawing.Point(134, 71)
        Me.numRPS.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numRPS.Minimum = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.numRPS.Name = "numRPS"
        Me.numRPS.Size = New System.Drawing.Size(65, 20)
        Me.numRPS.TabIndex = 2
        Me.numRPS.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(122, 13)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "Revolutions Per Second"
        '
        'lblRadius2
        '
        Me.lblRadius2.AutoSize = True
        Me.lblRadius2.Location = New System.Drawing.Point(203, 47)
        Me.lblRadius2.Name = "lblRadius2"
        Me.lblRadius2.Size = New System.Drawing.Size(43, 13)
        Me.lblRadius2.TabIndex = 71
        Me.lblRadius2.Text = "microns"
        '
        'numRadius2
        '
        Me.numRadius2.DecimalPlaces = 3
        Me.numRadius2.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numRadius2.Location = New System.Drawing.Point(134, 45)
        Me.numRadius2.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numRadius2.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.numRadius2.Name = "numRadius2"
        Me.numRadius2.Size = New System.Drawing.Size(65, 20)
        Me.numRadius2.TabIndex = 1
        Me.numRadius2.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(66, 47)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 13)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Ch2 Radius"
        '
        'lblLineSpacing
        '
        Me.lblLineSpacing.AutoSize = True
        Me.lblLineSpacing.Location = New System.Drawing.Point(203, 99)
        Me.lblLineSpacing.Name = "lblLineSpacing"
        Me.lblLineSpacing.Size = New System.Drawing.Size(43, 13)
        Me.lblLineSpacing.TabIndex = 65
        Me.lblLineSpacing.Text = "microns"
        '
        'lblRadius1
        '
        Me.lblRadius1.AutoSize = True
        Me.lblRadius1.Location = New System.Drawing.Point(203, 21)
        Me.lblRadius1.Name = "lblRadius1"
        Me.lblRadius1.Size = New System.Drawing.Size(43, 13)
        Me.lblRadius1.TabIndex = 64
        Me.lblRadius1.Text = "microns"
        '
        'numLineSpacing
        '
        Me.numLineSpacing.DecimalPlaces = 3
        Me.numLineSpacing.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numLineSpacing.Location = New System.Drawing.Point(134, 97)
        Me.numLineSpacing.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numLineSpacing.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.numLineSpacing.Name = "numLineSpacing"
        Me.numLineSpacing.Size = New System.Drawing.Size(65, 20)
        Me.numLineSpacing.TabIndex = 3
        Me.numLineSpacing.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(59, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 13)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Line Spacing"
        '
        'numRadius1
        '
        Me.numRadius1.DecimalPlaces = 3
        Me.numRadius1.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numRadius1.Location = New System.Drawing.Point(134, 19)
        Me.numRadius1.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.numRadius1.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.numRadius1.Name = "numRadius1"
        Me.numRadius1.Size = New System.Drawing.Size(65, 20)
        Me.numRadius1.TabIndex = 0
        Me.numRadius1.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(66, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "Ch1 Radius"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1001, 267)
        Me.Controls.Add(Me.grpSpiral)
        Me.Controls.Add(Me.grpStaticPositions)
        Me.Controls.Add(Me.grpRecordParam)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.lstDeviceList)
        Me.Controls.Add(Me.btnListDevices)
        Me.Controls.Add(Me.btnDisconnect)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LC.400 Example"
        Me.grpRecordParam.ResumeLayout(False)
        Me.grpRecordParam.PerformLayout()
        CType(Me.numCyclesPerSample, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numNumberSamples, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpStaticPositions.ResumeLayout(False)
        Me.grpStaticPositions.PerformLayout()
        CType(Me.numCh2DigPosition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numCh1DigPosition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpSpiral.ResumeLayout(False)
        Me.grpSpiral.PerformLayout()
        CType(Me.numStepVelocity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numDwell, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numRPS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numRadius2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numLineSpacing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numRadius1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnListDevices As System.Windows.Forms.Button
    Friend WithEvents lstDeviceList As System.Windows.Forms.ListBox
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents btnDisconnect As System.Windows.Forms.Button
    Friend WithEvents tmrCheckSpiralScanState As System.Windows.Forms.Timer
    Friend WithEvents grpRecordParam As System.Windows.Forms.GroupBox
    Friend WithEvents chkRecordSpiral As System.Windows.Forms.CheckBox
    Friend WithEvents lblRecTime As System.Windows.Forms.Label
    Friend WithEvents label70 As System.Windows.Forms.Label
    Friend WithEvents numCyclesPerSample As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnSaveToFile As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents numNumberSamples As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnStartRecording As System.Windows.Forms.Button
    Friend WithEvents tmrCheckForRecComplete As System.Windows.Forms.Timer
    Friend WithEvents dlgSaveRecording As System.Windows.Forms.SaveFileDialog
    Friend WithEvents grpStaticPositions As System.Windows.Forms.GroupBox
    Friend WithEvents numCh2DigPosition As System.Windows.Forms.NumericUpDown
    Friend WithEvents numCh1DigPosition As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblCh2RangeUnits2 As System.Windows.Forms.Label
    Friend WithEvents lblCh2RangeUnits1 As System.Windows.Forms.Label
    Friend WithEvents lblCh2SensorValue As System.Windows.Forms.Label
    Friend WithEvents txtCh2SensorValue As System.Windows.Forms.TextBox
    Friend WithEvents lblCh2DigitalPosCmd As System.Windows.Forms.Label
    Friend WithEvents lblCh1RangeUnits2 As System.Windows.Forms.Label
    Friend WithEvents lblCh1RangeUnits1 As System.Windows.Forms.Label
    Friend WithEvents lblCh1SensorValue As System.Windows.Forms.Label
    Friend WithEvents btnQuerySensor As System.Windows.Forms.Button
    Friend WithEvents txtCh1SensorValue As System.Windows.Forms.TextBox
    Friend WithEvents lblCh1DigitalPosCmd As System.Windows.Forms.Label
    Friend WithEvents grpSpiral As System.Windows.Forms.GroupBox
    Friend WithEvents btnStopSpiral As System.Windows.Forms.Button
    Friend WithEvents btnStartSpiral As System.Windows.Forms.Button
    Friend WithEvents optDecreasing As System.Windows.Forms.RadioButton
    Friend WithEvents optIncreasing As System.Windows.Forms.RadioButton
    Friend WithEvents lblVelocity As System.Windows.Forms.Label
    Friend WithEvents numStepVelocity As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents numDwell As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents numRPS As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblRadius2 As System.Windows.Forms.Label
    Friend WithEvents numRadius2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblLineSpacing As System.Windows.Forms.Label
    Friend WithEvents lblRadius1 As System.Windows.Forms.Label
    Friend WithEvents numLineSpacing As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents numRadius1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
