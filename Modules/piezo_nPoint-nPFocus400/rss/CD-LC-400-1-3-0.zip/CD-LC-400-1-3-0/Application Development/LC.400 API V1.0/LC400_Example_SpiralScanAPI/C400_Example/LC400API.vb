﻿Imports System.Text
Imports System.Runtime.InteropServices

Module LC400API
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function buildAvailUSB_devList(ByRef numDevices As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getAvailUSB_devInfo(ByVal deviceIndex As Integer, ByVal serialNumber As StringBuilder, ByVal deviceDescription As StringBuilder) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function connectUSB(ByVal USBListIndex As Integer, ByRef connectionID As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function disconnect(ByVal connectionID As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getNumChannels(ByVal connectionID As Integer, ByRef numChannels As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getRange(ByVal connectionID As Integer, ByVal channel As Integer, ByRef range As Single, ByRef distanceUnits As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setServoState(ByVal connectionID As Integer, ByVal channel As Integer, ByVal servoState As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getServoState(ByVal connectionID As Integer, ByVal channel As Integer, ByRef servoState As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setDigPosition(ByVal connectionID As Integer, ByVal channel As Integer, ByVal position As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getDigPosition(ByVal connectionID As Integer, ByVal channel As Integer, ByRef position As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSensorMonitor(ByVal connectionID As Integer, ByVal channel As Integer, ByRef sensorMonitor As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setTrajEnable(ByVal connectionID As Integer, ByVal channel As Integer, ByVal enableState As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getTrajEnable(ByVal connectionID As Integer, ByVal channel As Integer, ByRef enableState As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function singleTrajMove(ByVal connectionID As Integer, ByVal ch1Pos As Single, ByVal ch2Pos As Single, ByVal ch3Pos As Single, _
                                   ByVal vLimit As Single, ByVal aLimit As Single, ByVal jLimit As Single, ByVal dwellTime As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getTrajStatus(ByVal connectionID As Integer, ByRef status As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function stopTraj(ByVal connectionID As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setRecPointer(ByVal connectionID As Integer, ByVal recBufferIndex As Integer, ByVal channel As Integer, ByVal recNode As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function startRec(ByVal connectionID As Integer, ByVal numSamples As Integer, ByVal loopCyclesPerSample As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getRecStatus(ByVal connectionID As Integer, ByRef status As Integer, ByRef index As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getScaledRecBuffer(ByVal connectionID As Integer, ByVal recBufferIndex As Integer, ByVal retBuffer() As Single, ByVal retBufferSize As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setInteger(ByVal connectionID As Integer, ByVal address As Integer, ByVal value As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getInteger(ByVal connectionID As Integer, ByVal address As Integer, ByRef retValue As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setDiscreteIntArray(ByVal connectionID As Integer, ByVal addresses() As Integer, ByVal addressesLength As Integer, ByVal values() As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getDiscreteIntArray(ByVal connectionID As Integer, ByVal addresses() As Integer, ByVal addressesLength As Integer, ByVal retValues() As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setSingle(ByVal connectionID As Integer, ByVal address As Integer, ByVal value As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSingle(ByVal connectionID As Integer, ByVal address As Integer, ByRef retValue As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setDouble(ByVal connectionID As Integer, ByVal address As Integer, ByVal value As Double) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getDouble(ByVal connectionID As Integer, ByVal address As Integer, ByRef retValue As Double) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setByteArray(ByVal connectionID As Integer, ByVal startAddress As Integer, ByVal byteArray() As Byte, ByVal byteArrayLength As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getByteArray(ByVal connectionID As Integer, ByVal startAddress As Integer, ByVal retArray() As Byte, ByVal retArrayLength As Integer, ByVal maxBytesPerRead As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function saveConfigToController(ByVal connectionID As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSaveConfigStatus(ByVal connectionID As Integer, ByRef status As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function saveWaveformToController(ByVal connectionID As Integer, ByVal channel As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSaveWaveformStatus(ByVal connectionID As Integer, ByRef status As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function loadWaveform(ByVal connectionID As Integer, ByVal channel As Integer, ByVal waveformData() As Single, ByVal waveformDataLength As Integer, _
                                 ByVal loopCyclesPerPoint As Integer, ByVal iterations As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function simWaveformStart(ByVal connectionID As Integer, ByVal ch1Start As Integer, ByVal ch2Start As Integer, ByVal ch3Start As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getWaveformParameters(ByVal connectionID As Integer, ByVal channel As Integer, ByRef enable As Integer, ByRef active As Integer, ByRef dataLength As Integer, _
                                          ByRef loopCyclesPerPoint As Integer, ByRef iterations As Integer, ByRef iterationsCount As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function stopCh1Ch2Ch3Waveforms(ByVal connectionID As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setSpiralParameters(ByVal connectionID As Integer, ByVal spiralAxis1 As Integer, ByVal spiralAxis2 As Integer, ByVal axis1Radius As Single, ByVal axis2Radius As Single, _
                                        ByVal lineSpacing As Single, ByVal revPerSec As Single, ByVal radiusStepVel As Single, ByVal dwellTime As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSpiralParameters(ByVal connectionID As Integer, ByRef spiralAxis1 As Integer, ByRef spiralAxis2 As Integer, ByRef axis1Radius As Single, ByRef axis2Radius As Single, _
                                        ByRef lineSpacing As Single, ByRef revPerSec As Single, ByRef radiusStepVel As Single, ByRef dwellTime As Single) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function setSpiralFrameParameters(ByVal connectionID As Integer, ByVal frameAxis As Integer, ByVal frameStepSize As Single, ByVal numFrames As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSpiralFrameParameters(ByVal connectionID As Integer, ByRef frameAxis As Integer, ByRef frameStepSize As Single, ByRef numFrames As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function startSpiralScan(ByVal connectionID As Integer, ByVal startValue As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function getSpiralScanStatus(ByVal connectionID As Integer, ByRef status As Integer) As Integer

    End Function
    <DllImport("LC400API.dll", CallingConvention:=CallingConvention.Cdecl)> _
    Public Function stopSpiralScan(ByVal connectionID As Integer) As Integer

    End Function
End Module
