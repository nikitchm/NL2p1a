//LC400API.h - Contains the function declarations
#pragma once

#ifdef LC400API_EXPORTS
#define LC400API_port __declspec(dllexport)
#else
#define LC400API_port __declspec(dllimport)
#endif

typedef unsigned char byte;

extern "C" LC400API_port int setInteger(int, int, int);
extern "C" LC400API_port int getInteger(int, int, int&);
extern "C" LC400API_port int getDiscreteIntArray(int, int[], int, int[]);
extern "C" LC400API_port int setDiscreteIntArray(int, int[], int, int[]);
extern "C" LC400API_port int setSingle(int, int, float);
extern "C" LC400API_port int getSingle(int, int, float&);
extern "C" LC400API_port int setDouble(int, int, double);
extern "C" LC400API_port int getDouble(int, int, double&);
extern "C" LC400API_port int setByteArray(int, int, byte[], int);
extern "C" LC400API_port int getByteArray(int, int, byte[], int, int);
extern "C" LC400API_port int buildAvailUSB_devList(int&);
extern "C" LC400API_port int getAvailUSB_devInfo(int, char*, char*);
extern "C" LC400API_port int disconnect(int);
extern "C" LC400API_port int connectUSB(int, int&);
extern "C" LC400API_port int initControllerStruct(int);
extern "C" LC400API_port int getNumChannels(int, int&);
extern "C" LC400API_port int getRange(int, int, float&, int&);
extern "C" LC400API_port int setServoState(int, int, int);
extern "C" LC400API_port int getServoState(int, int, int&);
extern "C" LC400API_port int setDigPosition(int, int, float);
extern "C" LC400API_port int getDigPosition(int, int, float&);
extern "C" LC400API_port int getSensorMonitor(int, int, float&);
extern "C" LC400API_port int saveConfigToController(int);
extern "C" LC400API_port int getSaveConfigStatus(int, int&);
extern "C" LC400API_port int saveWaveformToController(int, int);
extern "C" LC400API_port int getSaveWaveformStatus(int, int&);
extern "C" LC400API_port int setTrajEnable(int, int, int);
extern "C" LC400API_port int getTrajEnable(int, int, int&);
extern "C" LC400API_port int singleTrajMove(int, float, float, float, float, float, float, float);
extern "C" LC400API_port int getTrajStatus(int, int&);
extern "C" LC400API_port int stopTraj(int);
extern "C" LC400API_port int loadWaveform(int, int, float[], int, int, int);
extern "C" LC400API_port int simWaveformStart(int, int, int, int);
extern "C" LC400API_port int getWaveformParameters(int, int, int&, int&, int&, int&, int&, int&);
extern "C" LC400API_port int stopCh1Ch2Ch3Waveforms(int);
extern "C" LC400API_port int setSpiralParameters(int, int, int, float, float, float, float, float, float);
extern "C" LC400API_port int getSpiralParameters(int, int&, int&, float&, float&, float&, float&, float&, float&);
extern "C" LC400API_port int setSpiralFrameParameters(int, int, float, int);
extern "C" LC400API_port int getSpiralFrameParameters(int, int&, float&, int&);
extern "C" LC400API_port int startSpiralScan(int, int);
extern "C" LC400API_port int getSpiralScanStatus(int, int&);
extern "C" LC400API_port int stopSpiralScan(int);
extern "C" LC400API_port int setRecPointer(int, int, int, int);
extern "C" LC400API_port int startRec(int, int, int);
extern "C" LC400API_port int getRecStatus(int, int&, int&);
extern "C" LC400API_port int getScaledRecBuffer(int, int, float[], int);

